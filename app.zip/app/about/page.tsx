// app/about/page.tsx
import styles from './about.module.scss';

export default function About() {
  return (
    <main className={styles.aboutPage}>
      <section className={styles.heroAbout}>
        <div className="container">
          <h1>About Us</h1>
          <p>We are a global leader in telecommunication infrastructure and services.</p>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div className={styles.missionText}>
              <h2>Our Mission</h2>
              <p>
                To bridge the digital divide by providing reliable, high-speed connectivity
                that empowers communities, businesses, and governments to thrive in a
                hyper-connected world.
              </p>
              <p>
                We innovate at the intersection of fiber optics, 5G, and cloud-native
                software to deliver unparalleled performance and security.
              </p>
            </div>
            <div className={styles.missionImage}>
              <div className={styles.imagePlaceholder}>
                <span>🌍</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2 className="section-title">Our Core Values</h2>
          <p className="section-subtitle">The principles that guide every decision we make.</p>
          <div className={styles.valuesGrid}>
            <div className={styles.valueCard}>
              <div className={styles.valueIcon}>🔒</div>
              <h3>Trust & Security</h3>
              <p>We protect data and privacy with the highest standards of encryption and compliance.</p>
            </div>
            <div className={styles.valueCard}>
              <div className={styles.valueIcon}>⚡</div>
              <h3>Speed & Agility</h3>
              <p>We deliver solutions fast and adapt quickly to evolving technology landscapes.</p>
            </div>
            <div className={styles.valueCard}>
              <div className={styles.valueIcon}>🤝</div>
              <h3>Partnership</h3>
              <p>We collaborate transparently with clients to co-create value and long-term success.</p>
            </div>
            <div className={styles.valueCard}>
              <div className={styles.valueIcon}>🌱</div>
              <h3>Sustainability</h3>
              <p>We invest in green technologies to reduce carbon footprint and build a better future.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <h2 className="section-title">Leadership Team</h2>
          <p className="section-subtitle">Experts driving innovation in telecom.</p>
          <div className={styles.teamGrid}>
            <div className={styles.teamMember}>
              <div className={styles.avatar}>👩‍💼</div>
              <h4>Jane Doe</h4>
              <span>CEO & Co‑founder</span>
            </div>
            <div className={styles.teamMember}>
              <div className={styles.avatar}>👨‍💻</div>
              <h4>John Smith</h4>
              <span>CTO</span>
            </div>
            <div className={styles.teamMember}>
              <div className={styles.avatar}>👩‍🔧</div>
              <h4>Emily Chen</h4>
              <span>Head of Network Engineering</span>
            </div>
            <div className={styles.teamMember}>
              <div className={styles.avatar}>👨‍📊</div>
              <h4>Michael Brown</h4>
              <span>VP of Sales</span>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}