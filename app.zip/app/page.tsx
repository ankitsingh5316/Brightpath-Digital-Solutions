// app/page.tsx
import styles from './page.module.scss';

export default function Home() {
  return (
    <main>
      {/* Hero */}
      <section className={styles.hero}>
        <div className={styles.heroOrb1}></div>
        <div className={styles.heroOrb2}></div>
        <div className={styles.heroOrb3}></div>
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <span className={styles.heroBadge}>⚡ Next-Gen Telecom</span>
            <h1>
              Connecting the Future <br />
              <span className={styles.highlight}>with Speed & Reliability</span>
            </h1>
            <p>
              We deliver cutting-edge 5G networks, fiber-optic solutions, and IoT
              connectivity to empower businesses and communities worldwide.
            </p>
            <div className={styles.heroActions}>
              <a href="#features" className={styles.btnPrimary}>
                Explore Solutions
              </a>
              <a href="/contact" className={styles.btnOutline}>
                Contact Us
              </a>
            </div>
          </div>
          <div className={styles.heroImage}>
            {/* Replace with an actual illustration or image */}
            <div className={styles.heroPlaceholder}>
              <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="200" cy="150" r="120" fill="rgba(0,184,148,0.15)" />
                <circle cx="200" cy="150" r="80" fill="rgba(0,184,148,0.25)" />
                <circle cx="200" cy="150" r="40" fill="rgba(0,184,148,0.4)" />
                <path d="M120 180 L200 120 L280 180" stroke="#00b894" strokeWidth="4" strokeLinecap="round" />
                <path d="M140 210 L200 160 L260 210" stroke="#fdcb6e" strokeWidth="4" strokeLinecap="round" />
                <circle cx="200" cy="120" r="6" fill="#fdcb6e" />
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className={styles.features}>
        <div className="container">
          <h2 className="section-title">Our Core Solutions</h2>
          <p className="section-subtitle">
            End-to-end telecommunication services designed for the digital era.
          </p>
          <div className={styles.featuresGrid}>
            <div className={styles.featureCard}>
              <div className={styles.featureIcon}>📶</div>
              <h3>5G Networks</h3>
              <p>Ultra-low latency, massive bandwidth, and seamless coverage for smart cities.</p>
            </div>
            <div className={styles.featureCard}>
              <div className={styles.featureIcon}>🔗</div>
              <h3>Fiber Optic</h3>
              <p>High-speed, reliable backbone infrastructure for data-intensive applications.</p>
            </div>
            <div className={styles.featureCard}>
              <div className={styles.featureIcon}>🌐</div>
              <h3>IoT Connectivity</h3>
              <p>Secure and scalable device management for industrial and consumer IoT.</p>
            </div>
            <div className={styles.featureCard}>
              <div className={styles.featureIcon}>☁️</div>
              <h3>Cloud Communications</h3>
              <p>Unified voice, video, and messaging solutions hosted on global cloud.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid}>
            <div className={styles.statItem}>
              <span className={styles.statNumber}>10+</span>
              <span className={styles.statLabel}>Years of Excellence</span>
            </div>
            <div className={styles.statItem}>
              <span className={styles.statNumber}>500+</span>
              <span className={styles.statLabel}>Enterprise Clients</span>
            </div>
            <div className={styles.statItem}>
              <span className={styles.statNumber}>99.9%</span>
              <span className={styles.statLabel}>Uptime Guarantee</span>
            </div>
            <div className={styles.statItem}>
              <span className={styles.statNumber}>40+</span>
              <span className={styles.statLabel}>Global PoPs</span>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <h2>Ready to accelerate your connectivity?</h2>
            <p>
              Let’s talk about how our telecom solutions can transform your business.
            </p>
            <a href="/contact" className={styles.btnPrimary}>Get a Free Consultation</a>
          </div>
        </div>
      </section>
    </main>
  );
}