import styles from "./page.module.scss";

export default function PrivacyPolicy() {
  return (
    <section className={styles.privacy}>
      <div className={styles.container}>

        <h1>Privacy Policy</h1>

        <p>
          Welcome to My Website. Your privacy is important to us. This Privacy
          Policy explains how we collect, use, store, and protect your personal
          information when you visit or use our website.
        </p>

        <h2>1. Information We Collect</h2>

        <p>
          We may collect personal information such as your name, email address,
          phone number, and any information you voluntarily provide through our
          contact forms. We may also collect non-personal information such as
          browser type, device information, IP address, and pages visited.
        </p>

        <h2>2. How We Use Your Information</h2>

        <p>
          The information collected is used to improve our services, respond to
          your inquiries, personalize your experience, send important updates,
          and maintain the security of our website.
        </p>

        <h2>3. Cookies</h2>

        <p>
          Our website may use cookies to enhance user experience. Cookies help
          us remember your preferences, understand user behavior, and improve
          website performance. You can disable cookies through your browser
          settings if you prefer.
        </p>

        <h2>4. Data Security</h2>

        <p>
          We implement industry-standard security measures to protect your
          personal information from unauthorized access, disclosure,
          modification, or destruction. However, no online platform can
          guarantee complete security.
        </p>

        <h2>5. Third-Party Services</h2>

        <p>
          We may use trusted third-party services for analytics, hosting, or
          payment processing. These providers have their own privacy policies,
          and we encourage you to review them before using their services.
        </p>

        <h2>6. Your Rights</h2>

        <p>
          You have the right to access, update, or request deletion of your
          personal information. You may also opt out of marketing communications
          at any time by contacting us.
        </p>

        <h2>7. Changes to This Policy</h2>

        <p>
          We reserve the right to update this Privacy Policy whenever necessary.
          Any changes will be posted on this page along with the updated
          effective date.
        </p>

        <h2>8. Contact Us</h2>

        <p>
          If you have any questions regarding this Privacy Policy, please
          contact us via our Contact page or email us at
          info@mywebsite.com.
        </p>

      </div>
    </section>
  );
}