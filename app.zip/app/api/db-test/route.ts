import { NextResponse } from 'next/server';
import { getDbConnection } from '@/lib/db';

export async function GET() {
  try {
    const db = await getDbConnection();

    const result = await db.request().query(`
      SELECT 
        DB_NAME() AS database_name,
        GETDATE() AS server_time
    `);

    return NextResponse.json({
      success: true,
      message: 'SQL Server connected successfully',
      data: result.recordset,
    });
  } catch (error: unknown) {
    console.error('Database connection error:', error);

    const errorMessage =
      error instanceof Error ? error.message : String(error);

    return NextResponse.json(
      {
        success: false,
        message: 'Database connection failed',
        error: errorMessage,
      },
      { status: 500 }
    );
  }
}