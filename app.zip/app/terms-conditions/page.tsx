import styles from "./page.module.scss";

export default function TermsConditions() {
  return (
    <section className={styles.terms}>
      <div className={styles.container}>

        <h1>Terms & Conditions</h1>

        <p>
          Welcome to My Website. By accessing or using our website, you agree to
          comply with these Terms & Conditions. Please read them carefully before
          using our services.
        </p>

        <h2>1. Acceptance of Terms</h2>

        <p>
          By accessing this website, you acknowledge that you have read,
          understood, and agreed to be bound by these Terms & Conditions. If you
          do not agree with any part of these terms, please discontinue using
          this website immediately.
        </p>

        <h2>2. Use of Website</h2>

        <p>
          You agree to use this website only for lawful purposes. You must not
          use the website in any way that could damage, disable, overburden, or
          impair the functionality of the website or interfere with other users.
        </p>

        <h2>3. Intellectual Property</h2>

        <p>
          All content, including text, graphics, logos, images, designs, and
          software available on this website, is the property of My Website and
          is protected under applicable copyright and intellectual property
          laws.
        </p>

        <h2>4. User Responsibilities</h2>

        <p>
          Users are responsible for maintaining the confidentiality of their
          account information, ensuring the accuracy of submitted information,
          and complying with all applicable laws while using the website.
        </p>

        <h2>5. Third-Party Links</h2>

        <p>
          Our website may contain links to third-party websites. These links are
          provided for your convenience only. We are not responsible for the
          content, privacy practices, or availability of any external websites.
        </p>

        <h2>6. Limitation of Liability</h2>

        <p>
          We shall not be held liable for any direct, indirect, incidental, or
          consequential damages arising from your use of this website or your
          inability to access the website or its services.
        </p>

        <h2>7. Termination</h2>

        <p>
          We reserve the right to suspend or terminate access to our website at
          any time without prior notice if a user violates these Terms &
          Conditions or engages in activities that may harm the website or its
          users.
        </p>

        <h2>8. Changes to Terms</h2>

        <p>
          We may revise these Terms & Conditions from time to time. Updated
          versions will be published on this page, and continued use of the
          website after changes are made constitutes acceptance of those
          revisions.
        </p>

        <h2>9. Governing Law</h2>

        <p>
          These Terms & Conditions shall be governed by and interpreted in
          accordance with the laws of the applicable jurisdiction. Any disputes
          arising under these terms shall be resolved through the appropriate
          legal authorities.
        </p>

        <h2>10. Contact Information</h2>

        <p>
          If you have any questions or concerns regarding these Terms &
          Conditions, please contact us through our Contact page or email us at
          info@mywebsite.com. We will make every effort to respond to your
          inquiry promptly.
        </p>

      </div>
    </section>
  );
}