import Link from "next/link";

export default function Footer() {
  return (
    <footer className="footer">

      <div className="container">

        <div className="footer-top">

          {/* Logo Section */}
          <div className="footer-box">
            <h2 className="logo">MyWebsite</h2>

            <p>
              Modern Next.js website built with reusable components and
              responsive design.
            </p>
          </div>

          {/* Quick Links */}
          <div className="footer-box">
            <h3>Quick Links</h3>

            <ul>
              <li><Link href="/">Home</Link></li>
              <li><Link href="/about">About</Link></li>
              <li><Link href="/blog">Blog</Link></li>
              <li><Link href="/contact">Contact</Link></li>
            </ul>
          </div>

          {/* Social */}
          <div className="footer-box">
            <h3>Follow Us</h3>

            <ul>
              <li><a href="#">Facebook</a></li>
              <li><a href="#">Instagram</a></li>
              <li><a href="#">LinkedIn</a></li>
              <li><a href="#">Twitter</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="footer-box">
            <h3>Contact</h3>

            <ul>
              <li>Email: info@mywebsite.com</li>
              <li>Phone: +91 9876543210</li>
              <li>Delhi, India</li>
            </ul>
          </div>

        </div>

        <div className="footer-bottom">

          <p>© 2026 My Website. All Rights Reserved.</p>

          <div className="footer-policy">
            <Link href="/privacy-policy">Privacy Policy</Link>
            <span>|</span>
            <Link href="/terms-conditions">Terms & Conditions</Link>
          </div>

        </div>

      </div>

    </footer>
  );
}