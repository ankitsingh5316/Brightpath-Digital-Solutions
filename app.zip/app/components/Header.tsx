"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

export default function Header() {
  const [showHeader, setShowHeader] = useState(true);
  const lastScrollY = useRef(0);
  const timer = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const currentScroll = window.scrollY;

      // Clear previous timer
      if (timer.current) {
        clearTimeout(timer.current);
      }

      // Scroll Down → Hide Header
      if (currentScroll > lastScrollY.current && currentScroll > 80) {
        setShowHeader(false);
      }

      // Scroll Up → Show Header
      if (currentScroll < lastScrollY.current) {
        setShowHeader(true);
      }

      lastScrollY.current = currentScroll;

      // Scroll Stop → Show Header after 400ms
      timer.current = setTimeout(() => {
        setShowHeader(true);
      }, 400);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header className={`header ${showHeader ? "show" : "hide"}`}>
      <h2>My Website</h2>

      <nav>
        <Link href="/">Home</Link>
        <Link href="/about">About</Link>
        <Link href="/blog">Blog</Link>
        <Link href="/contact">Contact</Link>
      </nav>
    </header>
  );
}