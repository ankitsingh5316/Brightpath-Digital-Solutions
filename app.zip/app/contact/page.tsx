"use client";
import { useState } from "react";
import styles from "./contact.module.scss";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: ""
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    console.log(formData);

     setFormData({
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    });
  };

  return (
    <section className={styles.contact}>
      <div className={styles.container}>
        <h1>Contact Us</h1>
        <p>Have a question? We'd love to hear from you.</p>

        <form className={styles.contactForm} onSubmit={handleSubmit}>
          <div className={styles.formGroup}>
            <label>Full Name</label>
            <input type="text" placeholder="Enter your name" name="name" value={formData.name} onChange={handleChange} />
          </div>

          <div className={styles.formGroup}>
            <label>Email Address</label>
            <input type="email" placeholder="Enter your email" name="email" value={formData.email} onChange={handleChange} />
          </div>

          <div className={styles.formGroup}>
            <label>Phone Number</label>
            <input type="tel" placeholder="Enter your phone number" name="phone" value={formData.phone} onChange={handleChange} />
          </div>

          <div className={styles.formGroup}>
            <label>Subject</label>
            <input type="text" placeholder="Enter subject" name="subject" value={formData.subject} onChange={handleChange} />
          </div>

          <div className={styles.formGroup}>
            <label>Message</label>
            <textarea rows={5} placeholder="Write your message" name="message" value={formData.message} onChange={handleChange}></textarea>
          </div>

          <button type="submit" className={styles.btn}>
            Send Message
          </button>
        </form>
      </div>
    </section>
  );
}