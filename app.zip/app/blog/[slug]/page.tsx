import styles from "./page.module.scss";

const blogs = [
  {
    id: 1,
    slug: "next-js-guide",
    title: "Complete Next.js Guide",
    image: "https://picsum.photos/1000/500?1",
    description: "Learn Next.js from beginner to advanced.",
    content:
      "This is a complete guide to Next.js. Here you can write your full blog content. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque, ipsum.",
  },
  {
    id: 2,
    slug: "react-hooks",
    title: "React Hooks Explained",
    image: "https://picsum.photos/1000/500?2",
    description: "Learn React Hooks.",
    content:
      "React Hooks are used to manage state and lifecycle methods inside functional components.",
  },
  {
    id: 3,
    slug: "typescript",
    title: "Why TypeScript?",
    image: "https://picsum.photos/1000/500?3",
    description: "Learn TypeScript.",
    content:
      "TypeScript improves code quality and reduces runtime errors.",
  },
  {
    id: 4,
    slug: "angular-best-practices",
    title: "Angular Best Practices",
    image: "https://picsum.photos/1000/500?4",
    description: "Improve your Angular application with best practices.",
    content:
      "Angular best practices help you build scalable and maintainable applications. Learn about folder structure, reusable components, lazy loading, performance optimization, and coding standards for professional Angular development.",
  },
  {
    id: 5,
    slug: "css-flexbox-guide",
    title: "CSS Flexbox Guide",
    image: "https://picsum.photos/1000/500?5",
    description: "Master CSS Flexbox layout.",
    content:
      "CSS Flexbox is a powerful layout module that makes it easy to align and distribute space among items in a container. Learn about flex-direction, justify-content, align-items, flex-wrap, and responsive layouts.",
  },
  {
    id: 6,
    slug: "javascript-es6-features",
    title: "JavaScript ES6 Features",
    image: "https://picsum.photos/1000/500?6",
    description: "Explore modern JavaScript ES6 features.",
    content:
      "ES6 introduced many useful features such as let and const, arrow functions, template literals, destructuring, spread operators, promises, modules, and classes. These features make JavaScript cleaner and more powerful.",
  },
  {
    id: 7,
    slug: "responsive-web-design",
    title: "Responsive Web Design",
    image: "https://picsum.photos/1000/500?7",
    description: "Build websites that work on every device.",
    content:
      "Responsive Web Design ensures your website looks great on desktops, tablets, and mobile devices. Learn about media queries, flexible grids, responsive images, and mobile-first development techniques.",
  }
]; 

export default async function BlogDetails({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const blog = blogs.find((item) => item.slug === slug);

  if (!blog) {
    return <h1>Blog Not Found</h1>;
  }

  return (
    // <section className={styles.blogDetails}>
    //   <div className={styles.container}>
    //     <img src={blog.image} alt={blog.title} />

    //     <h1>{blog.title}</h1>

    //     <p>{blog.content}</p>

    //     <p>
    //       Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores saepe possimus eligendi eaque repellendus! Nulla ex illo excepturi ipsa ab repellat praesentium nam quos, vero, eum quod corporis, dolorum explicabo architecto. Commodi dolorem inventore ut est mollitia quaerat impedit! Rem consequatur, soluta aliquam sapiente deleniti labore eveniet illum autem consectetur illo quo impedit minima optio dicta natus voluptate repellat fuga adipisci cumque porro aut rerum maiores vel tenetur. Ipsam at placeat rem asperiores adipisci nisi eius mollitia porro illo fugit tempore dicta, enim nam iusto vel et, earum reiciendis quas ducimus sit nobis maiores facilis? Quod possimus sint quidem enim ex quo vitae vero reiciendis dolor voluptatem quas sed natus ratione illum voluptatum quam nulla tempora dolore, ipsa eligendi numquam sequi voluptate illo. Veniam suscipit quisquam alias possimus. Labore magni a temporibus placeat architecto necessitatibus autem. Suscipit consectetur pariatur aliquid corporis? Vitae, dicta dolore cupiditate repudiandae libero nesciunt repellendus neque voluptates fuga quisquam. Modi asperiores magni neque a perferendis earum, nesciunt vero provident nostrum beatae, unde, ea quo molestiae consectetur fugit sit ut minus in ab aspernatur. Animi veritatis, repudiandae deserunt soluta voluptatem unde facere neque quos quam sunt voluptas quas quo earum laborum officiis, vel pariatur obcaecati, nemo possimus molestiae dolor impedit. Fugit nam ea maiores doloribus necessitatibus aliquid similique distinctio deserunt eligendi voluptatem itaque aut id ex aliquam eum, quibusdam nulla vero hic laudantium rem iusto suscipit dolor. Sint sit, quam in quasi necessitatibus similique, cumque hic sed saepe neque ipsa corporis facere, fugit expedita doloribus porro. Rerum praesentium facere sapiente architecto dolorum animi minus officiis, magnam error nemo non officia porro nihil possimus. Molestias necessitatibus repellendus voluptate aspernatur sunt, corporis doloribus, laborum assumenda corrupti recusandae facilis possimus beatae vel voluptatum placeat numquam soluta quis rem nostrum maxime? Libero, minima autem amet dolor architecto pariatur mollitia. Fugit enim unde reprehenderit temporibus facere veniam expedita non, placeat, optio sit modi in aspernatur doloribus! Quod beatae numquam illo. Repellendus hic totam perspiciatis error tempore voluptatem consequuntur commodi enim nesciunt minus cupiditate ipsam officiis ullam, illo dolore dolorem beatae amet obcaecati fuga, pariatur exercitationem iure voluptatibus officia. Id officiis rem alias minima commodi dolor quis nesciunt ullam odio hic repellendus sunt, praesentium obcaecati cupiditate? Eum, quisquam? Magnam qui eos cumque necessitatibus? Maiores voluptatum inventore animi! Eaque sequi voluptatibus iure? Labore dolores veniam illo ab consectetur ratione consequatur molestias! Deserunt, mollitia minima amet enim explicabo earum. Minus quaerat consequatur facere, cum explicabo et voluptas nostrum velit consequuntur, placeat, eos laudantium libero! Modi, fugit reiciendis error suscipit quibusdam rem perferendis impedit minus similique maxime. Quis aperiam quod, voluptas illo laudantium illum non pariatur at corrupti praesentium ipsam nemo modi officia inventore dolore quaerat, laboriosam, delectus quas architecto fugit a beatae? Corrupti animi quasi modi totam. Aliquid unde quo saepe itaque labore magni maxime et ex, doloribus quia dolorem repellat eos vitae sit asperiores, officia ab, praesentium esse suscipit? Iste voluptatum vitae quaerat accusantium, inventore ex incidunt illo id laborum. Iure similique magnam quo praesentium perferendis nobis tempore unde fuga in, voluptatibus eligendi culpa. Delectus officia odio eaque sit optio vitae provident alias. Inventore illum numquam accusamus explicabo soluta eos blanditiis enim tempore excepturi animi, accusantium vero temporibus nam harum doloremque praesentium ipsa sapiente veritatis voluptatibus quae iste maxime delectus sed deserunt. Quibusdam iusto consequatur provident adipisci sed, ad fugit tenetur doloremque aperiam dicta, hic eveniet incidunt velit possimus? Aut, nesciunt sed labore inventore, neque eveniet sequi blanditiis ducimus modi reiciendis rem impedit non beatae delectus atque sunt? Iure consequatur explicabo, accusamus ipsa eum laborum, autem omnis ex et qui, beatae natus animi obcaecati iusto! Impedit temporibus, deleniti velit dolorem aliquam aperiam quae placeat iusto repudiandae consequuntur. Magni eum impedit, voluptas delectus ipsa nemo pariatur repudiandae perferendis eligendi, nulla minima itaque sed? Suscipit cum omnis commodi natus, impedit blanditiis unde velit obcaecati, sequi, animi voluptate aspernatur. Exercitationem cupiditate illo vero corrupti officiis ut minus quo atque ipsa suscipit, quos dolores non quaerat odio quam voluptatem, delectus recusandae blanditiis est quasi architecto. Ea ipsum atque, impedit magni ipsa eos repellat veritatis deserunt. Nobis, nisi eos impedit dolor et fugit. Vitae natus blanditiis perspiciatis impedit dicta aspernatur, amet sint ut error necessitatibus tenetur dolore facere vel, quos magnam quidem expedita, libero ipsum. Laborum a tenetur aliquam, id ducimus eius perspiciatis, nostrum consequuntur eveniet reprehenderit quas, totam dicta natus harum eligendi molestias at temporibus! Esse aspernatur adipisci ullam accusantium veniam sequi placeat recusandae, eum ab corrupti impedit quisquam, nihil sit! Sit, nesciunt molestias? Assumenda, obcaecati! Dolor molestias reiciendis architecto incidunt optio repudiandae sunt, harum adipisci voluptates, similique quo pariatur magni tempora quia debitis eos est dignissimos neque velit dolorum sed dolores numquam! Esse obcaecati pariatur error, doloremque in expedita veniam quasi veritatis ipsum eaque nisi, tenetur vel, nobis laboriosam ratione consequatur! Necessitatibus voluptatum eveniet molestias? Aliquam possimus nesciunt aperiam nostrum, mollitia recusandae expedita quaerat sunt blanditiis explicabo, provident numquam neque reiciendis fuga consequuntur. Accusantium commodi quia cumque, reprehenderit tempora natus similique pariatur earum rem explicabo, quod cupiditate blanditiis autem, necessitatibus facere! Tempore mollitia dolore accusamus? Illo, voluptas voluptatibus recusandae similique animi, rerum vitae in cum asperiores a nulla, id minus corrupti quos et delectus ad. Quos, tempora voluptatibus? Nihil architecto sequi adipisci nostrum fuga, quis enim rem amet consectetur, error quasi officia placeat magnam. Repellat, obcaecati repudiandae error dolor necessitatibus adipisci commodi voluptatum provident aperiam blanditiis consequuntur optio aliquam soluta ex ea delectus alias asperiores rem? Rerum, tempore dolores? Eligendi voluptatibus deserunt nesciunt harum, rerum libero temporibus. Commodi quod vel eligendi ratione reprehenderit nesciunt expedita corporis! Corrupti libero, eum repudiandae quas deleniti ratione sed a error repellat illum voluptates animi, magni sapiente ipsum, dolorum nisi quaerat quam. Quibusdam corporis voluptatum eius totam magnam quas perferendis, itaque quos culpa porro labore adipisci laborum facere dolores rem delectus non. Velit temporibus vel at possimus perferendis! Distinctio et quidem dolor ad quos quibusdam ipsum molestias ipsam. Nemo excepturi nostrum eum maxime earum atque, molestiae recusandae consequatur eius? Inventore placeat quasi facilis quos saepe deleniti quaerat magnam vel facere aliquam, quia dolorem necessitatibus in quo! Perspiciatis possimus officia inventore hic recusandae.
    //     </p>
    //   </div>
    // </section>
    <section className={styles.blogDetails}>
      <div className={styles.container}>

        <img
          src={blog.image}
          alt={blog.title}
          className={styles.image}
        />

        <div className={styles.meta}>
          <span>Technology</span>
          <span>•</span>
          <span>August 2026</span>
          <span>•</span>
          <span>8 min read</span>
        </div>

        <h1 className={styles.title}>
          {blog.title}
        </h1>

        <p className={styles.description}>
          {blog.description}
        </p>

        <div className={styles.content}>

          <p>{blog.content}</p>

          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit.
            Illum tempora molestiae eligendi nemo exercitationem,
            pariatur quasi reprehenderit eaque ipsum sed.
          </p>

          <h2>Why Should You Learn This?</h2>

          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit.
            Voluptatibus molestias temporibus repellendus dolore,
            nostrum asperiores nemo consectetur.
          </p>

          <blockquote>
            "The best way to learn web development is by building
            real-world projects consistently."
          </blockquote>

          <h2>Key Takeaways</h2>

          <ul>
            <li>Understand the basic concepts.</li>
            <li>Practice with small projects.</li>
            <li>Use reusable components.</li>
            <li>Follow a proper folder structure.</li>
            <li>Keep learning every day.</li>
          </ul>

          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit.
            Necessitatibus, repellendus. Lorem ipsum dolor sit amet
            consectetur adipisicing elit.
          </p>

        </div>

        <div className={styles.back}>
          <a href="/blog">← Back to Blogs</a>
        </div>

      </div>
    </section>
  );
}