import Link from "next/link";
import styles from "./blog.module.scss";

const blogs = [
  {
    id: 1,
    slug: "next-js-guide",
    title: "Complete Next.js Guide",
    image: "https://picsum.photos/400/250?1",
    description:
      "Learn Next.js step by step from beginner to advanced level."
  },
  {
    id: 2,
    slug: "react-hooks",
    title: "React Hooks Explained",
    image: "https://picsum.photos/400/250?2",
    description:
      "Understand useState, useEffect and other React Hooks."
  },
  {
    id: 3,
    slug: "typescript",
    title: "Why TypeScript?",
    image: "https://picsum.photos/400/250?3",
    description:
      "Discover why TypeScript is becoming essential for React projects."
  },
  {
    id: 4,
    slug: "angular-best-practices",
    title: "Angular Best Practices",
    image: "https://picsum.photos/1000/500?4",
    description: "Improve your Angular application with best practices.",
  },
  {
    id: 5,
    slug: "css-flexbox-guide",
    title: "CSS Flexbox Guide",
    image: "https://picsum.photos/1000/500?5",
    description: "Master CSS Flexbox layout.",
  },
  {
    id: 6,
    slug: "javascript-es6-features",
    title: "JavaScript ES6 Features",
    image: "https://picsum.photos/1000/500?6",
    description: "Explore modern JavaScript ES6 features.",
  },
  {
    id: 7,
    slug: "responsive-web-design",
    title: "Responsive Web Design",
    image: "https://picsum.photos/1000/500?7",
    description: "Build websites that work on every device.",
  }
];

export default function Blog() {
  return (
    <section className={styles.blog}>
  <div className={styles.container}>
    <h1 className={styles.title}>Latest Blogs</h1>

    <div className={styles.blogGrid}>
      {blogs.map((blog) => (
        <div className={styles.card} key={blog.id}>
          <img src={blog.image} alt={blog.title} />

          <div className={styles.content}>
            <h3>{blog.title}</h3>

            <p>{blog.description}</p>

            <Link href={`/blog/${blog.slug}`}>
              Read More →
            </Link>
          </div>
        </div>
      ))}
    </div>
  </div>
</section>
  );
}